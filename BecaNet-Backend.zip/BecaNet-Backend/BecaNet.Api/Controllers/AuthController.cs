using Microsoft.AspNetCore.Mvc;
using BecaNet.Api.DTOs;
using System.Security.Cryptography;
using System.Text;

namespace BecaNet.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        // NOTA: Reemplazar por tu DbContext real de BecaNet si usas Entity Framework
        // Por ejemplo: private readonly BecaNetDbContext _context;

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterDto model)
        {
            if (!ModelState.IsValid)
                return BadRequest(new AuthResponseDto { Exito = false, Mensaje = "Datos inválidos en el formulario." });

            // TODO: Validar si el usuario ya existe en la BD
            // var usuarioExistente = await _context.Usuarios.FirstOrDefaultAsync(u => u.Email == model.Email);
            // if (usuarioExistente != null) 
            //     return BadRequest(new AuthResponseDto { Exito = false, Mensaje = "El correo ya está registrado." });

            // Hash de contraseña básico (reemplazar con BCrypt o ASP.NET Identity en producción)
            string passwordHash = Convert.ToBase64String(SHA256.HashData(Encoding.UTF8.GetBytes(model.Password)));

            // TODO: Guardar en la base de datos
            // var nuevoUsuario = new Usuario { Nombre = model.Nombre, Email = model.Email, PasswordHash = passwordHash, Rol = "Solicitante" };
            // _context.Usuarios.Add(nuevoUsuario);
            // await _context.SaveChangesAsync();

            return Ok(new AuthResponseDto
            {
                Exito = true,
                Mensaje = "Usuario registrado correctamente. Ya puedes iniciar sesión."
            });
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginDto model)
        {
            if (!ModelState.IsValid)
                return BadRequest(new AuthResponseDto { Exito = false, Mensaje = "Credenciales incompletas." });

            // TODO: Buscar usuario en la base de datos y verificar password
            // var usuario = await _context.Usuarios.FirstOrDefaultAsync(u => u.Email == model.Email);
            // if (usuario == null || !VerificarPassword(model.Password, usuario.PasswordHash))
            //     return Unauthorized(new AuthResponseDto { Exito = false, Mensaje = "Correo o contraseña incorrectos." });

            // Simulación de generación de JWT/Sesión exitosa
            string tokenSimulado = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.BecaNetSessionToken";

            return Ok(new AuthResponseDto
            {
                Exito = true,
                Mensaje = "Inicio de sesión exitoso",
                Token = tokenSimulado,
                Usuario = model.Email,
                Rol = "Solicitante"
            });
        }
    }
}