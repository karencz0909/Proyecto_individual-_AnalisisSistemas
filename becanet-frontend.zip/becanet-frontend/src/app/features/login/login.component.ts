import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { SesionService } from '../../services/sesion.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './login.component.html'
})
export class LoginComponent {
  credentials = { correo: '', contrasena: '' };
  mensajeError = '';
  cargando = false; // Declarada la variable requerida por la plantilla HTML

  constructor(
    private authService: AuthService,
    private sesionService: SesionService,
    private router: Router
  ) {}

  onSubmit() {
    this.cargando = true;
    this.mensajeError = '';

    this.authService.login(this.credentials).subscribe({
      next: (res) => {
        this.sesionService.iniciarSesion(res);
        this.redirigirSegunRol(res.role);
      },
      error: (err) => {
        this.mensajeError = err.error?.mensaje || 'Credenciales inválidas';
        this.cargando = false;
      }
    });
  }

  private redirigirSegunRol(rol: string) {
    switch (rol) {
      case 'ESTUDIANTE':
        this.router.navigate(['/mi-solicitud']);
        break;
      case 'COORDINADOR':
        this.router.navigate(['/solicitudes-admin']);
        break;
      case 'EVALUADOR':
        this.router.navigate(['/evaluaciones']);
        break;
      default:
        this.router.navigate(['/']);
        break;
    }
  }
}