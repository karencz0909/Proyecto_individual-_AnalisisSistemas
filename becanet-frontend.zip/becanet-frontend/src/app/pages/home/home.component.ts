import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { SesionService } from '../../services/sesion.service';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './home.component.html'
})
export class HomeComponent {

  constructor(
    private sesionService: SesionService,
    private router: Router
  ) {}

  postular(): void {
    if (!this.sesionService.estaAutenticado()) {
      this.router.navigate(['/login']);
    } else if (this.sesionService.obtenerRol() === 'ESTUDIANTE') {
      this.router.navigate(['/mi-solicitud']);
    }
  }

  esEstudianteOInvitado(): boolean {
    const rol = this.sesionService.obtenerRol();
    return !rol || rol === 'ESTUDIANTE';
  }
}